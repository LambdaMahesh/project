<?php
require_once("config.php");

$profile_img=$_POST['profile_img'];
$qualification=$_POST['qualification'];
$work_type=$_POST['work_type'];
$institute=$_POST['institute'];
$certifiacte=$_POST['certifiacte'];
$cost=$_POST['cost'];
$avilable_to=$_POST['avilable_to'];
$avilable_from=$_POST['avilable_from'];
$w_id=$_POST['wid'];
//$resp=array();

//$sql="Insert into worker_reg values('$work_name','$work_email','$work_pwd','$work_phno','$work_type')";

$result=mysqli_query($conn,"insert into skill_account(work_id,profile_pic,qulaification,work_expirience,work_institution,institution_certificate,cost,availability_from,available_to) 
values('$w_id','$profile_img','$qualification','$work_type','$institute','$certifiacte','$cost','$avilable_from','$avilable_to')");
 
  if($result){
	echo $result;
}
else{
	
	
}  


?>