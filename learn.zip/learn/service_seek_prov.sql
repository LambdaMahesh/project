-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 18, 2018 at 04:44 PM
-- Server version: 10.1.28-MariaDB
-- PHP Version: 7.1.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `service_seek_prov`
--

-- --------------------------------------------------------

--
-- Table structure for table `cusomer`
--

CREATE TABLE `cusomer` (
  `cost_id` int(11) NOT NULL,
  `name` varchar(25) NOT NULL,
  `email` varchar(40) NOT NULL,
  `password` varchar(20) NOT NULL,
  `phone` bigint(20) NOT NULL,
  `address1` varchar(50) NOT NULL,
  `address2` varchar(50) DEFAULT NULL,
  `city` varchar(30) NOT NULL,
  `date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `cusomer`
--

INSERT INTO `cusomer` (`cost_id`, `name`, `email`, `password`, `phone`, `address1`, `address2`, `city`, `date`) VALUES
(4, 'kdjjgcgh', 'kjscgkjgg@sjhg.s', 'sy', 5432456677, 'ksjgj', 'kgk', 'kugkjg', '2018-11-02'),
(5, 'hgdhg', 'dhfd@hgc', 'jyjfjf', 7474765646, 'jdhthf', 'mhjfkyf', 'jkyyfkuff', '2018-10-31'),
(6, 'yourjob', 'kkfhcv', 'dkjf', 1234567890, ',dkf', ',kdkv', 'Bangalore', '2018-11-15');

-- --------------------------------------------------------

--
-- Table structure for table `skill_account`
--

CREATE TABLE `skill_account` (
  `skill_id` int(11) NOT NULL,
  `work_id` int(11) NOT NULL,
  `profile_pic` varchar(100) NOT NULL,
  `qulaification` varchar(200) NOT NULL,
  `work_expirience` varchar(100) NOT NULL,
  `work_institution` varchar(200) NOT NULL,
  `institution_certificate` varchar(100) NOT NULL,
  `cost` int(11) NOT NULL,
  `availability_from` varchar(200) NOT NULL,
  `available_to` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `skill_account`
--

INSERT INTO `skill_account` (`skill_id`, `work_id`, `profile_pic`, `qulaification`, `work_expirience`, `work_institution`, `institution_certificate`, `cost`, `availability_from`, `available_to`) VALUES
(11, 24, 'C:fakepath78-1024x640.jpg', 'dkjscbs', 'Fresher', 'sdshk', 'C:fakepath78-1024x640.jpg', 122, '14:36', ''),
(12, 25, 'C:fakepath78-1024x640.jpg', 'dskj', 'Experienced', 'uwgys', 'C:fakepath78-1024x640.jpg', 1212, '', '');

-- --------------------------------------------------------

--
-- Table structure for table `worker_basic`
--

CREATE TABLE `worker_basic` (
  `basic_id` int(11) NOT NULL,
  `govt_id_type` varchar(25) NOT NULL,
  `govt_id_no` varchar(20) NOT NULL,
  `govt_id_path` varchar(100) DEFAULT NULL,
  `city` varchar(50) NOT NULL,
  `date` date NOT NULL,
  `worker_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `worker_basic`
--

INSERT INTO `worker_basic` (`basic_id`, `govt_id_type`, `govt_id_no`, `govt_id_path`, `city`, `date`, `worker_id`) VALUES
(22, 'Dl', '89498t7448t9y4987', 'C:fakepath78-1024x640.jpg', 'Bangalore', '2018-11-07', 24),
(23, 'Adhar', '89498t7448t9y4987', 'C:fakepath78-1024x640.jpg', 'Bangalore', '2018-11-09', 25);

-- --------------------------------------------------------

--
-- Table structure for table `worker_location`
--

CREATE TABLE `worker_location` (
  `worker_id` int(11) NOT NULL,
  `location_id` int(11) NOT NULL,
  `address1` varchar(200) NOT NULL,
  `address2` varchar(200) NOT NULL,
  `pincode` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `worker_location`
--

INSERT INTO `worker_location` (`worker_id`, `location_id`, `address1`, `address2`, `pincode`) VALUES
(24, 13, 'efhjdvchv', 'gdchjgxjhcg', 263642),
(25, 14, 'dsfkhs', 'lkhkdkh', 23323);

-- --------------------------------------------------------

--
-- Table structure for table `worker_reg`
--

CREATE TABLE `worker_reg` (
  `worker_id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `email` varchar(40) NOT NULL,
  `password` varchar(25) NOT NULL,
  `phone` bigint(20) NOT NULL,
  `type` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `worker_reg`
--

INSERT INTO `worker_reg` (`worker_id`, `name`, `email`, `password`, `phone`, `type`) VALUES
(24, 'yourjob', 'maheshhegde112@gmail.com', '13243552', 1234567890, 'Accountant'),
(25, 'yourjob1234', 'maheshhegde117@gmail.com', '23623', 7632548732754, 'Accountant');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cusomer`
--
ALTER TABLE `cusomer`
  ADD PRIMARY KEY (`cost_id`);

--
-- Indexes for table `skill_account`
--
ALTER TABLE `skill_account`
  ADD PRIMARY KEY (`skill_id`);

--
-- Indexes for table `worker_basic`
--
ALTER TABLE `worker_basic`
  ADD PRIMARY KEY (`basic_id`);

--
-- Indexes for table `worker_location`
--
ALTER TABLE `worker_location`
  ADD PRIMARY KEY (`location_id`);

--
-- Indexes for table `worker_reg`
--
ALTER TABLE `worker_reg`
  ADD PRIMARY KEY (`worker_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cusomer`
--
ALTER TABLE `cusomer`
  MODIFY `cost_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `skill_account`
--
ALTER TABLE `skill_account`
  MODIFY `skill_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `worker_basic`
--
ALTER TABLE `worker_basic`
  MODIFY `basic_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `worker_location`
--
ALTER TABLE `worker_location`
  MODIFY `location_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `worker_reg`
--
ALTER TABLE `worker_reg`
  MODIFY `worker_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
