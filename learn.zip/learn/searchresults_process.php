<?php
require_once("config.php");

$type=$_POST['type'];
$string1="";
$worker_id=array();
$profile_pic=array();
$resp=array();

//$sql="Insert into worker_reg values('$work_name','$work_email','$work_pwd','$work_phno','$work_type')";

$result=mysqli_query($conn,"select * from worker_reg where type='$type' order by name");

  $count=mysqli_num_rows($result); 
  $rr=0;
/*  while($row=mysqli_fetch_array($result)) 
	{
		
		$worker_id[$rr]=$row['worker_id'];
		$rr++;
	}  */
 

/*  if($type=="Accountant")
{
	for($i=0;$i<sizeof($worker_id);$i++){
$sql1="select profile_pic from skill_account where work_id='$worker_id[$i]' ";

$result1=mysqli_query($conn,$sql1);
$rk=0;
while($row1=mysqli_fetch_array($result1))
	{
		
		$pic=$row1['profile_pic'];
		$profile_pic[$rk]=str_replace("C:fakepath", "uploaded_images/", $pic);
		$rk++;
	}


}
} */
 
//

 	$jj=0; 
	//".$profile_pic[$jj]."
 while($row2=mysqli_fetch_array($result))
	{
		
	$string1="<div class='fh5co-entry padding'>
					<img src='' alt='img'>
					<div>
						<h2>".$row2['name']."</h2>
						<p>".$row2['phone']."</p>
					</div>
				</div>";
				$resp["string".$jj]=$string1;
					
	
	} 
	  
	
echo json_encode($resp); 

?>